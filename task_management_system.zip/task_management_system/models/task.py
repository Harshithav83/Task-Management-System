from datetime import datetime
from enum import Enum
import uuid

class Priority(Enum):
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"
    CRITICAL = "Critical"
    
class Status(Enum):
    PENDING = "Pending"
    IN_PROGRESS = "In Progress"
    COMPLETED = "Completed"
    CANCELLED = "Cancelled" 

class Task:
    _counter = 0
    
    @classmethod
    def set_counter(cls, value):
        """Set the counter value (useful when loading from file)"""
        cls._counter=value
        
    @classmethod
    def get_next_id(cls):
        """Get the next available ID in format: 01, 02, 03, ..."""
        cls._counter += 1
        return f"{cls._counter:02d}"
    
    def __init__(self, title, description="", priority=Priority.MEDIUM,
                 category=None, due_date=None, assigned_to=None):
        self.id= Task.get_next_id()
        self.title = title
        self.description = description
        self.priority = priority
        self.status = Status.PENDING
        self.category = category
        self.created_at = datetime.now()
        self.updated_at = datetime.now()
        self.due_date = due_date
        self.assigned_to = assigned_to
        self.tags = []
        self.comments = []
        self.subtasks = []
            
    def to_dict(self):
        """Convert task to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'priority': self.priority.value,
            'status': self.status.value,
            'category': self.category,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'due_date': self.due_date.isoformat() if self.due_date else None,
            'assigned_to': self.assigned_to,
            'tags': self.tags,
            'comments': self.comments,
            'subtasks': self.subtasks
        }
    
    @classmethod
    def from_dict(cls, data):
        """Create task from dictionary"""
        task = cls(
            title=data['title'],
            description=data['description'],
            priority=Priority(data['priority']),
            category=data['category'],
            due_date=datetime.fromisoformat(data['due_date']) if data['due_date'] else None,
            assigned_to=data['assigned_to']
        )
        task.id = data['id']
        task.status = Status(data['status'])
        task.created_at = datetime.fromisoformat(data['created_at'])
        task.updated_at = datetime.fromisoformat(data['updated_at'])
        task.tags = data.get('tags', [])
        task.comments = data.get('comments', [])
        task.subtasks = data.get('subtasks', [])
        
        try:
            if isinstance(task.id, str) and task.id.isdigit():
                id_num=int(task.id)
            elif isinstance(task.id, int):
                id_num=task.id
            else:
                id_num=0
            if id_num >=cls._counter:
                cls._counter=id_num
        except (ValueError, TypeError, AttributeError):
            pass
        return task
    
    def update_status(self, new_status):
        """Update task status"""
        self.status = new_status
        self.updated_at = datetime.now()
    
    def add_comment(self, comment):
        """Add comment to task"""
        self.comments.append({
            'text': comment,
            'timestamp': datetime.now().isoformat()
        })
        self.updated_at = datetime.now()
    
    def add_tag(self, tag):
        """Add tag to task"""
        if tag not in self.tags:
            self.tags.append(tag)
    
    def __str__(self):
        return f"[{self.id}] {self.title} - {self.status.value} ({self.priority.value})"