import uuid

class Category:
    def __init__(self, name, description="", color="blue"):
        self.id = str(uuid.uuid4())[:8]
        self.name = name
        self.description = description
        self.color = color
        self.task_count = 0
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'color': self.color,
            'task_count': self.task_count
        }
    
    @classmethod
    def from_dict(cls, data):
        category = cls(data['name'], data['description'], data['color'])
        category.id = data['id']
        category.task_count = data.get('task_count', 0)
        return category
    
    def __str__(self):
        return f"{self.name} ({self.task_count} tasks)"