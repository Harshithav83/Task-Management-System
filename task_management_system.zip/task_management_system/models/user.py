import uuid
from datetime import datetime

class User:
    def __init__(self, username, email, full_name=""):
        self.id = str(uuid.uuid4())[:8]
        self.username = username
        self.email = email
        self.full_name = full_name
        self.created_at = datetime.now()
        self.preferences = {
            'notifications': True,
            'theme': 'light'
        }
    
    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'full_name': self.full_name,
            'created_at': self.created_at.isoformat(),
            'preferences': self.preferences
        }
    
    @classmethod
    def from_dict(cls, data):
        user = cls(data['username'], data['email'], data['full_name'])
        user.id = data['id']
        user.created_at = datetime.fromisoformat(data['created_at'])
        user.preferences = data.get('preferences', {})
        return user
    
    def __str__(self):
        return f"{self.username} ({self.full_name})"