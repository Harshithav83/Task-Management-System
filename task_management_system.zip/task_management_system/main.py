#!/usr/bin/env python3
"""
Task Management System
A comprehensive command-line task management application
"""

from controllers.task_controller import TaskController
from views.console_view import ConsoleView
import sys

def main():
    """Main application entry point"""
    try:
        # Initialize controller and view
        controller = TaskController()
        view = ConsoleView(controller)
        
        # Display welcome message
        view.clear_screen()
        view.print_header("WELCOME TO TASK MANAGEMENT SYSTEM")
        print(f"{Fore.GREEN}Version 1.0.0{Style.RESET_ALL}")
        print(f"{Fore.WHITE}Manage your tasks efficiently and stay organized!{Style.RESET_ALL}")
        input(f"\n{Fore.CYAN}Press Enter to start...{Style.RESET_ALL}")
        
        # Run the application
        view.run()
        
    except KeyboardInterrupt:
        print(f"\n\n{Fore.YELLOW}Application interrupted by user{Style.RESET_ALL}")
    except Exception as e:
        print(f"\n{Fore.RED}An error occurred: {str(e)}{Style.RESET_ALL}")
        print("Please check your data files and try again.")
    finally:
        print(f"\n{Fore.CYAN}Goodbye!{Style.RESET_ALL}")
        sys.exit(0)

if __name__ == "__main__":
    # Import colorama here to avoid circular imports
    from colorama import init, Fore, Style
    init()
    main()