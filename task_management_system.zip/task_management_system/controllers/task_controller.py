from models.task import Task, Priority, Status
from models.category import Category
from utils.file_handler import FileHandler
from datetime import datetime, timedelta
from typing import List, Optional

class TaskController:
    def __init__(self):
        self.file_handler = FileHandler()
        self.tasks: List[Task] = []
        self.categories: List[Category] = []
        self.load_data()
    
    def load_data(self):
        """Load all data from files"""
        # Load tasks
        task_data = self.file_handler.load_tasks()
        self.tasks = []
        max_id=0
        
        for data in task_data:
            task=Task.from_dict(data)
            self.tasks.append(task)
            
        try:
            if isinstance(task.id, str) and task.id.isdigit():
                id_num=int(task.id)
            elif isinstance(task.id, int):
                id_num=task.id
            else:
                id_num=0
            if id_num>max_id:
                max_id=id_num
        except:
            pass
        if max_id>0:
            Task._counter=max_id
        else:
            Task._counter=0
        
        # Load categories
        category_data = self.file_handler.load_categories()
        self.categories = [Category.from_dict(data) for data in category_data]
    
    def save_data(self):
        """Save all data to files"""
        self.file_handler.save_tasks(self.tasks)
        self.file_handler.save_categories(self.categories)
    
    def create_task(self, title, description="", priority=Priority.MEDIUM, 
                   category=None, due_date=None, assigned_to=None):
        """Create a new task"""
        task = Task(title, description, priority, category, due_date, assigned_to)
        self.tasks.append(task)
        self.save_data()
        return task
    
    def get_task(self, task_id):
        """Get task by ID"""
        for task in self.tasks:
            if task.id == task_id:
                return task
        return None
    
    def update_task(self, task_id, **kwargs):
        """Update task attributes"""
        task = self.get_task(task_id)
        if task:
            for key, value in kwargs.items():
                if hasattr(task, key) and value is not None:
                    setattr(task, key, value)
            task.updated_at = datetime.now()
            self.save_data()
            return True
        return False
    
    def delete_task(self, task_id):
        """Delete a task"""
        task = self.get_task(task_id)
        if task:
            self.tasks.remove(task)
            self.save_data()
            return True
        return False
    
    def get_tasks_by_status(self, status):
        """Get tasks by status"""
        return [task for task in self.tasks if task.status == status]
    
    def get_tasks_by_priority(self, priority):
        """Get tasks by priority"""
        return [task for task in self.tasks if task.priority == priority]
    
    def get_tasks_by_category(self, category_name):
        """Get tasks by category"""
        return [task for task in self.tasks if task.category == category_name]
    
    def get_overdue_tasks(self):
        """Get overdue tasks"""
        now = datetime.now()
        return [task for task in self.tasks 
                if task.due_date and task.due_date < now 
                and task.status != Status.COMPLETED]
    
    def get_upcoming_tasks(self, days=7):
        """Get tasks due in next X days"""
        now = datetime.now()
        future = now + timedelta(days=days)
        return [task for task in self.tasks 
                if task.due_date and now <= task.due_date <= future]
    
    def create_category(self, name, description="", color="blue"):
        """Create a new category"""
        category = Category(name, description, color)
        self.categories.append(category)
        self.save_data()
        return category
    
    def get_category(self, category_id):
        """Get category by ID"""
        for category in self.categories:
            if category.id == category_id:
                return category
        return None
    
    def get_category_by_name(self, name):
        """Get category by name"""
        for category in self.categories:
            if category.name.lower() == name.lower():
                return category
        return None
    
    def delete_category(self, category_id):
        """Delete a category"""
        category = self.get_category(category_id)
        if category:
            self.categories.remove(category)
            self.save_data()
            return True
        return False
    
    def search_tasks(self, query):
        """Search tasks by title or description"""
        query = query.lower()
        return [task for task in self.tasks 
                if query in task.title.lower() or query in task.description.lower()]
    
    def get_statistics(self):
        """Get task statistics"""
        total = len(self.tasks)
        completed = len([t for t in self.tasks if t.status == Status.COMPLETED])
        pending = len([t for t in self.tasks if t.status == Status.PENDING])
        in_progress = len([t for t in self.tasks if t.status == Status.IN_PROGRESS])
        overdue = len(self.get_overdue_tasks())
        
        return {
            'total': total,
            'completed': completed,
            'pending': pending,
            'in_progress': in_progress,
            'overdue': overdue,
            'completion_rate': (completed / total * 100) if total > 0 else 0
        }