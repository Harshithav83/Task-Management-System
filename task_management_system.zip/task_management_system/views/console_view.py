from colorama import init, Fore, Back, Style
from tabulate import tabulate
from datetime import datetime
from models.task import Priority, Status
import os
import sys

# Initialize colorama
init(autoreset=True)

class ConsoleView:
    def __init__(self, task_controller):
        self.controller = task_controller
        self.current_user = None
    
    def clear_screen(self):
        """Clear the console screen"""
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def print_header(self, title):
        """Print formatted header"""
        print(f"\n{Fore.CYAN}{'='*60}")
        print(f"{Fore.YELLOW}{title:^60}")
        print(f"{Fore.CYAN}{'='*60}{Style.RESET_ALL}\n")
    
    def print_success(self, message):
        """Print success message"""
        print(f"{Fore.GREEN}✓ {message}{Style.RESET_ALL}")
    
    def print_error(self, message):
        """Print error message"""
        print(f"{Fore.RED}✗ {message}{Style.RESET_ALL}")
    
    def print_info(self, message):
        """Print info message"""
        print(f"{Fore.BLUE}ℹ {message}{Style.RESET_ALL}")
    
    def print_warning(self, message):
        """Print warning message"""
        print(f"{Fore.YELLOW}⚠ {message}{Style.RESET_ALL}")
    
    def get_user_input(self, prompt, required=True):
        """Get user input with validation"""
        while True:
            value = input(f"{Fore.CYAN}{prompt}: {Style.RESET_ALL}").strip()
            if required and not value:
                self.print_error("This field is required!")
            else:
                return value
    
    def get_choice(self, options, prompt="Select option"):
        """Get user choice from menu"""
        print(f"\n{Fore.MAGENTA}{prompt}:{Style.RESET_ALL}")
        for key, value in options.items():
            print(f"  {Fore.YELLOW}{key}{Style.RESET_ALL}. {value}")
        
        while True:
            choice = input(f"\n{Fore.CYAN}Enter choice: {Style.RESET_ALL}").strip()
            if choice in options:
                return choice
            self.print_error("Invalid choice!")
    
    def display_tasks(self, tasks, title="Tasks"):
        """Display tasks in table format"""
        if not tasks:
            self.print_info("No tasks found.")
            return
        
        table_data = []
        for task in tasks:
            # Color code based on priority
            priority_color = {
                Priority.LOW: Fore.GREEN,
                Priority.MEDIUM: Fore.YELLOW,
                Priority.HIGH: Fore.RED,
                Priority.CRITICAL: Fore.MAGENTA + Style.BRIGHT
            }.get(task.priority, Fore.WHITE)
            
            # Color code based on status
            status_color = {
                Status.PENDING: Fore.YELLOW,
                Status.IN_PROGRESS: Fore.BLUE,
                Status.COMPLETED: Fore.GREEN,
                Status.CANCELLED: Fore.RED
            }.get(task.status, Fore.WHITE)
            
            due_date = task.due_date.strftime("%Y-%m-%d") if task.due_date else "No due date"
            
            table_data.append([
                task.id,
                task.title[:30] + "..." if len(task.title) > 30 else task.title,
                priority_color + task.priority.value,
                status_color + task.status.value,
                task.category or "Uncategorized",
                due_date
            ])
        
        headers = ["ID", "Title", "Priority", "Status", "Category", "Due Date"]
        print(f"\n{Fore.CYAN}{title}{Style.RESET_ALL}")
        print(tabulate(table_data, headers=headers, tablefmt="grid"))
    
    def display_task_details(self, task):
        """Display detailed task information"""
        self.print_header(f"Task Details: {task.title}")
        
        print(f"{Fore.WHITE}ID: {Fore.YELLOW}{task.id}")
        print(f"{Fore.WHITE}Title: {Fore.YELLOW}{task.title}")
        print(f"{Fore.WHITE}Description: {Fore.YELLOW}{task.description}")
        print(f"{Fore.WHITE}Priority: {Fore.YELLOW}{task.priority.value}")
        print(f"{Fore.WHITE}Status: {Fore.YELLOW}{task.status.value}")
        print(f"{Fore.WHITE}Category: {Fore.YELLOW}{task.category or 'Uncategorized'}")
        print(f"{Fore.WHITE}Created: {Fore.YELLOW}{task.created_at.strftime('%Y-%m-%d %H:%M')}")
        print(f"{Fore.WHITE}Updated: {Fore.YELLOW}{task.updated_at.strftime('%Y-%m-%d %H:%M')}")
        print(f"{Fore.WHITE}Due Date: {Fore.YELLOW}{task.due_date.strftime('%Y-%m-%d') if task.due_date else 'Not set'}")
        
        if task.tags:
            print(f"{Fore.WHITE}Tags: {Fore.YELLOW}{', '.join(task.tags)}")
        
        if task.comments:
            print(f"\n{Fore.CYAN}Comments:{Style.RESET_ALL}")
            for comment in task.comments:
                print(f"  {Fore.WHITE}[{comment['timestamp'][:10]}] {comment['text']}")
    
    def main_menu(self):
        """Display main menu"""
        self.clear_screen()
        self.print_header("TASK MANAGEMENT SYSTEM")
        
        # Show statistics
        stats = self.controller.get_statistics()
        print(f"{Fore.WHITE}📊 Statistics:")
        print(f"  Total Tasks: {Fore.YELLOW}{stats['total']}")
        print(f"  Completed: {Fore.GREEN}{stats['completed']}")
        print(f"  Pending: {Fore.YELLOW}{stats['pending']}")
        print(f"  In Progress: {Fore.BLUE}{stats['in_progress']}")
        print(f"  Overdue: {Fore.RED}{stats['overdue']}")
        print(f"  Completion Rate: {Fore.CYAN}{stats['completion_rate']:.1f}%")
        
        # Show overdue tasks warning
        if stats['overdue'] > 0:
            self.print_warning(f"You have {stats['overdue']} overdue tasks!")
        
        # Main menu options
        options = {
            '1': 'View All Tasks',
            '2': 'Create New Task',
            '3': 'View Tasks by Status',
            '4': 'View Tasks by Priority',
            '5': 'Search Tasks',
            '6': 'Manage Categories',
            '7': 'View Statistics',
            '8': 'Exit'
        }
        
        choice = self.get_choice(options, "Main Menu")
        return choice
    
    def create_task_view(self):
        """View for creating a new task"""
        self.clear_screen()
        self.print_header("CREATE NEW TASK")
        
        # Get task details
        title = self.get_user_input("Title")
        description = self.get_user_input("Description", required=False)
        
        # Priority selection
        priority_options = {
            '1': Priority.LOW.value,
            '2': Priority.MEDIUM.value,
            '3': Priority.HIGH.value,
            '4': Priority.CRITICAL.value
        }
        priority_choice = self.get_choice(priority_options, "Select Priority")
        priority = list(Priority)[int(priority_choice) - 1]
        
        # Category selection
        categories = self.controller.categories
        category = None
        if categories:
            print(f"\n{Fore.CYAN}Available Categories:{Style.RESET_ALL}")
            for i, cat in enumerate(categories, 1):
                print(f"  {i}. {cat.name}")
            print("  n. New Category")
            
            cat_choice = input(f"{Fore.CYAN}Select category: {Style.RESET_ALL}").strip()
            if cat_choice.lower() == 'n':
                category = self.create_category_view()
            elif cat_choice.isdigit():
                try:
                    cat_index = int(cat_choice) - 1
                    if 0 <= cat_index < len(categories):
                        category = categories[cat_index].name
                except:
                    pass
        
        # Due date
        due_date_str = self.get_user_input("Due Date (YYYY-MM-DD)", required=False)
        due_date = None
        if due_date_str:
            try:
                due_date = datetime.fromisoformat(due_date_str)
            except ValueError:
                self.print_error("Invalid date format!")
        
        # Create task
        task = self.controller.create_task(
            title=title,
            description=description,
            priority=priority,
            category=category,
            due_date=due_date
        )
        
        self.print_success(f"Task created successfully! ID: {task.id}")
        input(f"\n{Fore.CYAN}Press Enter to continue...{Style.RESET_ALL}")
    
    def create_category_view(self):
        """View for creating a new category"""
        self.print_header("CREATE CATEGORY")
        
        name = self.get_user_input("Category name")
        description = self.get_user_input("Description", required=False)
        
        color_options = {
            '1': 'Red',
            '2': 'Blue',
            '3': 'Green',
            '4': 'Yellow',
            '5': 'Purple'
        }
        color_choice = self.get_choice(color_options, "Select color")
        color = list(color_options.values())[int(color_choice) - 1].lower()
        
        category = self.controller.create_category(name, description, color)
        self.print_success(f"Category '{name}' created successfully!")
        
        return name
    
    def view_all_tasks(self):
        """View all tasks"""
        self.clear_screen()
        self.print_header("ALL TASKS")
        
        tasks = self.controller.tasks
        self.display_tasks(tasks, "All Tasks")
        
        if tasks:
            task_id = self.get_user_input("Enter task ID to view details (or 'b' to go back)", required=False)
            if task_id and task_id != 'b':
                task = self.controller.get_task(task_id)
                if task:
                    self.view_task_details(task)
    
    def view_task_details(self, task):
        """View and manage task details"""
        while True:
            self.clear_screen()
            self.display_task_details(task)
            
            options = {
                '1': 'Update Status',
                '2': 'Edit Task',
                '3': 'Add Comment',
                '4': 'Add Tag',
                '5': 'Delete Task',
                '6': 'Back'
            }
            
            choice = self.get_choice(options, "Task Actions")
            
            if choice == '1':
                self.update_task_status(task)
            elif choice == '2':
                self.edit_task(task)
            elif choice == '3':
                self.add_comment(task)
            elif choice == '4':
                self.add_tag(task)
            elif choice == '5':
                if self.confirm_delete():
                    self.controller.delete_task(task.id)
                    self.print_success("Task deleted!")
                    input("Press Enter to continue...")
                    break
            elif choice == '6':
                break
    
    def update_task_status(self, task):
        """Update task status"""
        status_options = {
            '1': Status.PENDING.value,
            '2': Status.IN_PROGRESS.value,
            '3': Status.COMPLETED.value,
            '4': Status.CANCELLED.value
        }
        
        choice = self.get_choice(status_options, "Select new status")
        new_status = list(Status)[int(choice) - 1]
        
        task.update_status(new_status)
        self.controller.save_data()
        self.print_success(f"Status updated to {new_status.value}!")
        input("Press Enter to continue...")
    
    def edit_task(self, task):
        """Edit task details"""
        self.print_header(f"EDITING: {task.title}")
        
        new_title = self.get_user_input(f"Title [{task.title}]", required=False)
        if new_title:
            task.title = new_title
        
        new_description = self.get_user_input(f"Description [{task.description}]", required=False)
        if new_description:
            task.description = new_description
        
        self.controller.save_data()
        self.print_success("Task updated!")
        input("Press Enter to continue...")
    
    def add_comment(self, task):
        """Add comment to task"""
        comment = self.get_user_input("Enter comment")
        task.add_comment(comment)
        self.controller.save_data()
        self.print_success("Comment added!")
        input("Press Enter to continue...")
    
    def add_tag(self, task):
        """Add tag to task"""
        tag = self.get_user_input("Enter tag")
        task.add_tag(tag)
        self.controller.save_data()
        self.print_success("Tag added!")
        input("Press Enter to continue...")
    
    def confirm_delete(self):
        """Confirm delete action"""
        confirm = input(f"{Fore.RED}Are you sure you want to delete this task? (y/n): {Style.RESET_ALL}")
        return confirm.lower() == 'y'
    
    def view_by_status(self):
        """View tasks filtered by status"""
        status_options = {
            '1': Status.PENDING.value,
            '2': Status.IN_PROGRESS.value,
            '3': Status.COMPLETED.value,
            '4': Status.CANCELLED.value
        }
        
        choice = self.get_choice(status_options, "Select status")
        status = list(Status)[int(choice) - 1]
        
        tasks = self.controller.get_tasks_by_status(status)
        self.clear_screen()
        self.display_tasks(tasks, f"Tasks - {status.value}")
        input(f"\n{Fore.CYAN}Press Enter to continue...{Style.RESET_ALL}")
    
    def view_by_priority(self):
        """View tasks filtered by priority"""
        priority_options = {
            '1': Priority.LOW.value,
            '2': Priority.MEDIUM.value,
            '3': Priority.HIGH.value,
            '4': Priority.CRITICAL.value
        }
        
        choice = self.get_choice(priority_options, "Select priority")
        priority = list(Priority)[int(choice) - 1]
        
        tasks = self.controller.get_tasks_by_priority(priority)
        self.clear_screen()
        self.display_tasks(tasks, f"Tasks - {priority.value} Priority")
        input(f"\n{Fore.CYAN}Press Enter to continue...{Style.RESET_ALL}")
    
    def search_tasks_view(self):
        """Search tasks view"""
        self.clear_screen()
        self.print_header("SEARCH TASKS")
        
        query = self.get_user_input("Enter search term")
        tasks = self.controller.search_tasks(query)
        
        self.display_tasks(tasks, f"Search Results for '{query}'")
        input(f"\n{Fore.CYAN}Press Enter to continue...{Style.RESET_ALL}")
    
    def manage_categories(self):
        """Manage categories view"""
        while True:
            self.clear_screen()
            self.print_header("MANAGE CATEGORIES")
            
            if self.controller.categories:
                print(f"{Fore.CYAN}Existing Categories:{Style.RESET_ALL}")
                for category in self.controller.categories:
                    print(f"  {Fore.YELLOW}{category.name}{Style.RESET_ALL} - {category.description}")
            else:
                self.print_info("No categories found.")
            
            options = {
                '1': 'Create New Category',
                '2': 'Delete Category',
                '3': 'Back'
            }
            
            choice = self.get_choice(options, "Category Management")
            
            if choice == '1':
                self.create_category_view()
            elif choice == '2':
                self.delete_category_view()
            elif choice == '3':
                break
    
    def delete_category_view(self):
        """Delete category view"""
        if not self.controller.categories:
            self.print_error("No categories to delete!")
            input("Press Enter to continue...")
            return
        
        print(f"\n{Fore.CYAN}Select category to delete:{Style.RESET_ALL}")
        for i, cat in enumerate(self.controller.categories, 1):
            print(f"  {i}. {cat.name}")
        
        try:
            choice = int(self.get_user_input("Enter number", required=False)) - 1
            if 0 <= choice < len(self.controller.categories):
                category = self.controller.categories[choice]
                
                # Check if category is in use
                tasks_in_category = self.controller.get_tasks_by_category(category.name)
                if tasks_in_category:
                    self.print_warning(f"This category is used by {len(tasks_in_category)} tasks!")
                    confirm = input("Delete anyway? Tasks will become uncategorized. (y/n): ")
                    if confirm.lower() != 'y':
                        return
                
                self.controller.delete_category(category.id)
                self.print_success(f"Category '{category.name}' deleted!")
            else:
                self.print_error("Invalid selection!")
        except (ValueError, IndexError):
            self.print_error("Invalid input!")
        
        input("Press Enter to continue...")
    
    def view_statistics(self):
        """View detailed statistics"""
        self.clear_screen()
        self.print_header("DETAILED STATISTICS")
        
        stats = self.controller.get_statistics()
        
        # Overall stats
        print(f"{Fore.CYAN}Overall Statistics:{Style.RESET_ALL}")
        print(f"  Total Tasks: {Fore.YELLOW}{stats['total']}")
        print(f"  Completed Tasks: {Fore.GREEN}{stats['completed']}")
        print(f"  Pending Tasks: {Fore.YELLOW}{stats['pending']}")
        print(f"  In Progress: {Fore.BLUE}{stats['in_progress']}")
        print(f"  Overdue Tasks: {Fore.RED}{stats['overdue']}")
        print(f"  Completion Rate: {Fore.CYAN}{stats['completion_rate']:.1f}%")
        
        # Tasks by priority
        print(f"\n{Fore.CYAN}Tasks by Priority:{Style.RESET_ALL}")
        for priority in Priority:
            count = len(self.controller.get_tasks_by_priority(priority))
            print(f"  {priority.value}: {Fore.YELLOW}{count}")
        
        # Upcoming tasks
        upcoming = self.controller.get_upcoming_tasks(7)
        if upcoming:
            print(f"\n{Fore.CYAN}Tasks Due in Next 7 Days:{Style.RESET_ALL}")
            for task in upcoming[:5]:  # Show top 5
                due = task.due_date.strftime("%Y-%m-%d") if task.due_date else "No date"
                print(f"  {due}: {task.title}")
        
        input(f"\n{Fore.CYAN}Press Enter to continue...{Style.RESET_ALL}")
    
    def run(self):
        """Main application loop"""
        while True:
            choice = self.main_menu()
            
            if choice == '1':
                self.view_all_tasks()
            elif choice == '2':
                self.create_task_view()
            elif choice == '3':
                self.view_by_status()
            elif choice == '4':
                self.view_by_priority()
            elif choice == '5':
                self.search_tasks_view()
            elif choice == '6':
                self.manage_categories()
            elif choice == '7':
                self.view_statistics()
            elif choice == '8':
                self.print_success("Thank you for using Task Management System!")
                break