import json
import os
from pathlib import Path

class FileHandler:
    def __init__(self, data_dir="data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(exist_ok=True)
        
        self.tasks_file = self.data_dir / "tasks.json"
        self.users_file = self.data_dir / "users.json"
        self.categories_file = self.data_dir / "categories.json"
        
        # Initialize files if they don't exist
        self._init_file(self.tasks_file)
        self._init_file(self.users_file)
        self._init_file(self.categories_file)
    
    def _init_file(self, file_path):
        """Initialize JSON file if it doesn't exist"""
        if not file_path.exists():
            self.save_data(file_path, [])
    
    def save_data(self, file_path, data):
        """Save data to JSON file"""
        with open(file_path, 'w') as f:
            json.dump(data, f, indent=2)
    
    def load_data(self, file_path):
        """Load data from JSON file"""
        try:
            with open(file_path, 'r') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return []
    
    def save_tasks(self, tasks):
        """Save tasks to file"""
        self.save_data(self.tasks_file, [task.to_dict() for task in tasks])
    
    def load_tasks(self):
        """Load tasks from file"""
        return self.load_data(self.tasks_file)
    
    def save_users(self, users):
        """Save users to file"""
        self.save_data(self.users_file, [user.to_dict() for user in users])
    
    def load_users(self):
        """Load users from file"""
        return self.load_data(self.users_file)
    
    def save_categories(self, categories):
        """Save categories to file"""
        self.save_data(self.categories_file, [cat.to_dict() for cat in categories])
    
    def load_categories(self):
        """Load categories from file"""
        return self.load_data(self.categories_file)