import re
from datetime import datetime

class Validators:
    @staticmethod
    def validate_email(email):
        """Validate email format"""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(pattern, email) is not None
    
    @staticmethod
    def validate_date(date_str):
        """Validate date string"""
        try:
            datetime.fromisoformat(date_str)
            return True
        except ValueError:
            return False
    
    @staticmethod
    def validate_required(value, field_name):
        """Validate required field"""
        if not value or not str(value).strip():
            return False, f"{field_name} is required"
        return True, ""
    
    @staticmethod
    def validate_length(value, min_len=1, max_len=100, field_name=""):
        """Validate string length"""
        if len(value) < min_len:
            return False, f"{field_name} must be at least {min_len} characters"
        if len(value) > max_len:
            return False, f"{field_name} must be less than {max_len} characters"
        return True, ""